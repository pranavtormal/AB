<?php
/*Added by Suhas 23 May 2017 start*/
?>
<!DOCTYPE html>
<html>
<head>
	<script src="javascript/jquery-latest.min.js"></script>
	<script src="javascript/jspdf.min.js"></script>
	<script src="javascript/jspdf.plugin.autotable.js"></script>
	<script src="javascript/headerImg.js"></script>
	<script src="javascript/highchart.js"></script>
        <script src="javascript/exporting.js"></script>
        <script src="javascript/rgbcolor.js"></script>
        <script src="javascript/canvg.js"></script>
	<script>
		function selRad()
		{
			document.getElementById('IP_rad').checked = "true";
			enaDisableRange('0');
		}
		function enableRun()
		{
			document.getElementById('runbtn').disabled = "false";			
		}
	</script>
</head>
<body onload="selRad();" style="margin:0px;">
<link href="cssStyles/escanVAPT.css" rel="stylesheet" type="text/css" media="screen" />
<style>
  tr,td {text-align:left;}
</style>
<script>
function showDiv(divID,show) {
      var w=document.getElementById(divID);
      w.style.visibility=(show==1)?'visible':'hidden';
}

var pVul;
var nVul;
var unVul;
function createPieChart(id,chartType,Title,data) //function to create Pie Chart
                {
                        //console.log(id);
                        $(id).highcharts({
                                        chart:{
                                        type:chartType,
                                        backgroundColor:'#FFFFFF',
                                        plotBackgroundColor:'#FFFFFF',
                              },
                        credits:false, // to remove highchart.com link
                        title:{
                                text:Title
                              },
			 tooltip: {
                                        pointFormat: '{series.name}: <b>{point.y:.0f}</b>'
                                  },
                        plotOptions: {
                                        pie: {
                                                allowPointSelect: false,
                                                cursor: 'pointer',
                                                borderWidth:0,
                                                borderColor:null,
                                                size:200,
                                                dataLabels:{
                                                                enabled: true,
                                                                format: '{point.name}-{point.y:.0f}'
                                                           },
                                                showInLegend: true,
                                                series: {
                                                                states: {
                                                                            hover: {
                                                                                     enabled: false
                                                                                    }
                                                                        }
                                                        }

                                            }
                                      },
                        series:data
                });
        }//createPieChart end here

function resetAll(positiveVul,negativeVul,unknownVul)
{
	pVul = positiveVul;
	nVul = negativeVul;
	unVul = unknownVul;
	var id = $('#pieDiv');
        var Title = "eScan VAPT Report Summary";
        var chartType = "pie";
        var pdata = [{name:'Total',colorByPoint:true,data:[{name:'Not Vulnerable',color:'#42Ab6E',y:nVul},{name:'Vulnerable',color:'#F37A6C',y:pVul},{name:'Unknown',color:'#999999',y:unVul}]}];
createPieChart(id,chartType,Title,pdata);
$('#pieDiv').css('display','none');
	$.ajax({
		url : 'read_report.php',
		method : 'POST',
		data : {'p':'no'},
		success : function(resp){
			if(resp != "")
			{
				$('#resulReportDiv').html(resp);
				var len = $('#ExportTable tr').length;
                                if(len > 1)
                                {
                                        document.getElementById("table1").style.display = "";
                                        document.getElementById('txtlbl').style.display = "";
                                        document.getElementById('txtlbl1').style.display = "none";
                                        document.getElementById('pdfBtn').style.display = "";
                                        document.getElementById('htmlBtn').style.display = "";
                                        document.getElementById('runbtn').disabled = true;
                                }else if(len == 1){
                                        document.getElementById("table1").style.display = "";
                                        document.getElementById('txtlbl').style.display = "";
                                        document.getElementById('txtlbl1').style.display = "";
                                        document.getElementById('pdfBtn').style.display = "none";
                                        document.getElementById('htmlBtn').style.display = "none";
                                        document.getElementById('runbtn').disabled = true;
                                }
			}
		}
	});
}

function generateReport()
{
	//document.getElementById("screen1").style.display="block";
	document.getElementById("table1").style.display = "none";
	$.ajax({
		url : 'generateReportoutframe.php',
		method : 'post',
		success : function(resp){
			//document.getElementById("screen1").style.display="block";
			showDiv('resultDiv',1);
			$('#resultDiv').css("width","70%");
			$('#resultDiv').html(resp);
		}
	});
}

var qsFields = new Array();
function GetQueryFields() {
        var query = window.location.search.substring(1);
        var parms = query.split('&');
        for(var i = 0; i<parms.length; i++) {
                var pos = parms[i].indexOf('=');
                if (pos > 0) {
                        var key = parms[i].substring(0,pos);
                        var val = parms[i].substring(pos+1);
                        qsFields[key] = val;
                }
        }
}
function trimStr(str) {
        return str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
}
function roundcorner() {
        var str_StartIP_err = 'Wrong Starting IP Address!';
        var str_EndIP_err       = 'Wrong End IP Address!';
        var str_AERR_err        = 'IP - Subnet Already Exists';
        var str_ERR_err         = 'Starting IP Address must be less than Ending IP Address';

        messageMaker('myMsgStartIP', {message: str_StartIP_err});
        messageMaker('myMsgEndIP', {message: str_EndIP_err});
        messageMaker('myMsgAlreadyExst', {message: str_AERR_err});
        messageMaker('myMsgERR', {message: str_ERR_err});
        
        ResetErrMsg();
}
function ResetErrMsg() {
        document.getElementById("myMsgStartIP").style.display = "none";
        document.getElementById("myMsgEndIP").style.display = "none";
        document.getElementById("myMsgAlreadyExst").style.display = "none";
        document.getElementById("myMsgERR").style.display = "none";
}
function ValidateIP(value) {
        var ipaddr = value;
        ipaddr = ipaddr.replace( /\s/g, "");
    var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    
    if (re.test(ipaddr)) {
        var parts = ipaddr.split(".");        
        if (parseInt(parseFloat(parts[0])) == 0) {
            return false;
        }        
        if (parseInt(parseFloat(parts[3])) == 0) {
            return false;
        }        
        for (var i=0; i<parts.length; i++) {
            if (parseInt(parseFloat(parts[i])) > 255){
                return false;
            }
        }
        return true;
    } else {
        return false;
    }
}
function ValidIP(ipaddr) {
   var parts = ipaddr.split(".");
   if (parts[3] >= 255) {
      return false;
   } else {
      return true;
   }
}
function GetIPInteger(value) {
        var IPInt, IPInts = value.split(".");
        IPInt = (IPInts[0]*256*256*256)+(IPInts[1]*256*256)+(IPInts[2]*256)+IPInts[3];
        return IPInt;
}
function IsStartIpLTEndIP(firstip, lastip) {
        var first = firstip.split(".");
        var last  = lastip.split(".");
        
        if (parseInt(first[0]) <= parseInt(last[0])) {
                if (parseInt(first[1]) <= parseInt(last[1])) {
                        if (parseInt(first[2]) == parseInt(last[2])) {
                                if ((parseInt(first[3]) <parseInt(last[3])) || (parseInt(first[3]) == parseInt(last[3]))) {
                                        return true;
                                }
                        } else if (parseInt(first[2]) <parseInt(last[2])) {
                                return true;
                        }
                }
        }
        
        return false;
}
var IPVal;
function isIP(evt, tagid) {
                IPVal = document.getElementById(tagid).value;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode == 46) {
                        if (IPVal!="")
                        {
                                switch(tagid) {
                                        case "StartIP1": { document.getElementById("StartIP2").select(); break; }
                                        case "StartIP2": { document.getElementById("StartIP3").select(); break; }
                                        case "StartIP3": { document.getElementById("StartIP4").select(); break; }
                                        case "StartIP4": { document.getElementById("EndIP3").select(); break; }
                                        case "EndIP3":   { document.getElementById("EndIP4").select(); break; }
                                }
                        }
                        return false;
                }
    if (charCode > 31 && (charCode <46 || charCode==47 || charCode > 57)) {
                        return false;
    }
    else {
                        IPVal = IPVal + String.fromCharCode(charCode);
                        return true; 
    }         
}
function SetEndIP(tagid) {
        switch(tagid) {
                case "StartIP1": {
                        document.getElementById("EndIP1").value = document.getElementById("StartIP1").value;
                        break;
                }
                case "StartIP2": {
                        document.getElementById("EndIP2").value = document.getElementById("StartIP2").value;
                        break;
                }
		case "StartIP3":{
			document.getElementById("EndIP3").value = document.getElementById("StartIP3").value;
                        break;
		}
        }
}
function CheckSize(evt,tagid) {
	document.getElementById('txtlbl').style.display = "none";
	document.getElementById('savebtn').disabled = false;
        document.getElementById('runbtn').disabled = true;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        
        if (charCode > 31 && (charCode <46 || charCode == 47 || charCode > 57) && (charCode <46 || charCode > 57)
                                && (charCode<96 || charCode>105 ))  
                return false;
        
        var start1 = document.getElementById("StartIP1").value;
        var start2 = document.getElementById("StartIP2").value;
        var start3 = document.getElementById("StartIP3").value;
        var start4 = document.getElementById("StartIP4").value;
        var end3   = document.getElementById("EndIP3").value;
        var end4   = document.getElementById("EndIP4").value;
        
        // ----- for backspace
        if (charCode == 8) {
                if (IPVal=="")
                {
                        switch(tagid) {
                                case "StartIP2":{ 
                                        FocusTextBox("StartIP1");
                                        IPVal = document.getElementById("StartIP1").value;
                                        break;
                                }
                                case "StartIP3":{ 
                                        FocusTextBox("StartIP2");
                                        IPVal = document.getElementById("StartIP2").value;
                                        break;
                                }
                                case "StartIP4":{ 
                                        FocusTextBox("StartIP3"); 
                                        IPVal = document.getElementById("StartIP3").value;
                                        break; 
                                }
                                case "EndIP3": { 
                                        FocusTextBox("StartIP4"); 
                                        IPVal = document.getElementById("StartIP4").value;
                                        break; 
                                }
                                case "EndIP4":{ 
                                        FocusTextBox("EndIP3"); 
                                        IPVal = document.getElementById("EndIP3").value;
                                        break; 
                                }
                        }
                }
                else
                {
                        IPVal = document.getElementById(tagid).value;                   
                }
        }
        else
        {
                switch(tagid) {
                        case "StartIP1": {
                                if(start1.length == 3) {
                                        if (parseInt(start1) > 223) {
                                                document.getElementById("StartIP1").value = "223";
                                                document.getElementById("EndIP1").value = "223";
                                        }
                                        if (charCode!=16 && charCode!=9) {
                                                document.getElementById("StartIP2").select();
                                                IPVal = document.getElementById("StartIP2").value;
                                        }
                                } 
                                break; 
                        }
                        case "StartIP2": { 
                                if(start2.length == 3) {
                                        if (parseInt(start2) > 255) {
                                                document.getElementById("StartIP2").value = "255";
                                                document.getElementById("EndIP2").value = "255";
                                        }
                                        if (charCode!=16 && charCode!=9) {
                                                document.getElementById("StartIP3").select();
                                                IPVal = document.getElementById("StartIP3").value;
                                        }
                                }
                                break; 
                        }
                        case "StartIP3": { 
                                if(start3.length == 3) {
                                        if (parseInt(start3) > 255) {
                                                document.getElementById("StartIP3").value = "255";
                                        }
                                        if (charCode!=16 && charCode!=9) {
                                                document.getElementById("StartIP4").select();
                                                IPVal = document.getElementById("StartIP4").value;
                                        }
                                }
                                break; 
                        }
                        case "StartIP4":         { 
                                if(start4.length == 3) {
                                        if (parseInt(start4) > 254) {
                                                document.getElementById("StartIP4").value = "254";
                                        }
                                        if (charCode!=16 && charCode!=9) {
                                                document.getElementById("EndIP3").select();
                                                IPVal = document.getElementById("EndIP3").value;
                                        }
                                }
                                break; 
                        }
                        case "EndIP3":   { 
                                if(end3.length == 3) {
                                        if (parseInt(end3) > 255) {
                                                document.getElementById("EndIP3").value = "255";
                                        }
                                        if (charCode!=16 && charCode!=9) {
                                                document.getElementById("EndIP4").select();
                                                IPVal = document.getElementById("EndIP4").value;
                                        }
                                }
                                break; 
                        }
                        case "EndIP4":   { 
                                if(end4.length == 3) {
                                        if (parseInt(end4) > 254) {
                                                document.getElementById("EndIP4").value = "254";
                                        }
                                }
                                break; 
                        }
                }
        }
}
function enaDisableRange(op)
{
	document.getElementById("StartIP1").value = "";
	document.getElementById("StartIP2").value = "";
	document.getElementById("StartIP3").value = "";
	document.getElementById("StartIP4").value = "";
	
	document.getElementById("EndIP1").value = "";
	document.getElementById("EndIP2").value = "";
	document.getElementById("EndIP3").value = "";
	document.getElementById("EndIP4").value = "";

	document.getElementById('savebtn').disabled = false;
        document.getElementById('runbtn').disabled = true;
	document.getElementById('txtlbl').style.display = "none";	
	if(op === "0")
	{
		document.getElementById('startipTR').style.display = "";
		document.getElementById('endipTR').style.display = "none";
		//document.getElementById('chgcontaintxt').innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ "IP Address";
		document.getElementById('chgcontaintxt').innerHTML =  "IP Address";
		$('#chgcontaintxt').append('<b style="color:red;">*</b>:');
	}else if(op === "1"){
		document.getElementById('startipTR').style.display = "";
                document.getElementById('endipTR').style.display = "";
		document.getElementById('chgcontaintxt').innerHTML = "Starting IP Address";
		$('#chgcontaintxt').append('<b style="color:red;">*</b>:');
	}
}
function DisplayErrMessage(op)
{
        if(op === "myMsgStartIP")
        {
                document.getElementById('err_msg_ip').innerHTML = '<img src="images/icon_expired.gif" style="vertical-align:middle;padding-right:10px;"/ >' + "Wrong Starting IP Address!";
                $("#err_msg_ip").css("display","block");
        }
        else if(op === "myMsgEndIP"){
                document.getElementById('err_msg_ip').innerHTML = '<img src="images/icon_expired.gif" style="vertical-align:middle;padding-right:10px;"/ >' + "Wrong ending IP Address!";
                $("#err_msg_ip").css("display","block");
                //$("#err_msg_ip").css("display","none");
        }else if(op === "myMsgERR"){
                document.getElementById('err_msg_ip').innerHTML = '<img src="images/icon_expired.gif" style="vertical-align:middle;padding-right:10px;"/ >' + "Starting IP Address must be less than Ending IP Address!";
                $("#err_msg_ip").css("display","block");
        }else if(op === "myMsgAlreadyExst"){
                document.getElementById('err_msg_ip').innerHTML = '<img src="images/icon_expired.gif" style="vertical-align:middle;padding-right:10px;"/ >' + "IP - Subnet Already Exists!"; 
                $("#err_msg_ip").css("display","block");
        }
}
function jsSaveIPRange() 
{

	var e = document.getElementById("vulnera");
	var strUser = e.options[e.selectedIndex].value;

	if(document.getElementById('IP_rad').checked)
	{
		var radVal = "0";
		var startip = trimStr(document.getElementById("StartIP1").value);
		startip = startip + "." + trimStr(document.getElementById("StartIP2").value);
		startip = startip + "." + trimStr(document.getElementById("StartIP3").value);
		startip = startip + "." + trimStr(document.getElementById("StartIP4").value);
	}else if(document.getElementById('IP_range_rad').checked)
	{
		var radVal = "1";
		var startip = trimStr(document.getElementById("StartIP1").value);
		startip = startip + "." + trimStr(document.getElementById("StartIP2").value);
		startip = startip + "." + trimStr(document.getElementById("StartIP3").value);
		startip = startip + "." + trimStr(document.getElementById("StartIP4").value);

		var endip   = trimStr(document.getElementById("EndIP1").value);
		endip   = endip + "." + trimStr(document.getElementById("EndIP2").value);
		endip   = endip + "." + trimStr(document.getElementById("EndIP3").value);
		endip   = endip + "." + trimStr(document.getElementById("EndIP4").value);
	}
	var error   = false;

	//ResetErrMsg();
	if(document.getElementById('IP_rad').checked)	
	{
		if (startip == "") {
			error = true; 
			//DisplayErrMessage("myMsgStartIP");
			document.getElementById("StartIP1").focus();
		} else if (!ValidateIP(startip) || !ValidIP(startip)) {
			error = true;
			DisplayErrMessage("myMsgStartIP");
			document.getElementById("StartIP1").focus();
		}
	}else if(document.getElementById('IP_range_rad').checked){
		if (startip == "") {
			error = true; 
			//DisplayErrMessage("myMsgStartIP");
			document.getElementById("StartIP1").focus();
		} else if (!ValidateIP(startip) || !ValidIP(startip)) {
			error = true;
			DisplayErrMessage("myMsgStartIP");
			document.getElementById("StartIP1").focus();
		} else if (endip == "") {
			error = true;
			//DisplayErrMessage("myMsgEndIP");
		} else if (!ValidateIP(endip) || !ValidIP(endip)) {
			error = true;
			DisplayErrMessage("myMsgEndIP");
		} else if (!IsStartIpLTEndIP(startip, endip)) {
			error = true;
			DisplayErrMessage("myMsgERR");
		}
	}
	if (error == true) {return;}
	document.getElementById('err_msg_ip').style.display = "none";
	if(document.getElementById('IP_rad').checked)
	{
		var sb = startip;
	}else if(document.getElementById('IP_range_rad').checked){
		var sb = startip+"-"+endip;
	}

		$.ajax({
			url : 'vulnerableSettings.php',
			method : 'POST',
			data : {'radtyp':radVal,'vulnerabletyp':strUser,'ip':sb},
			success: function(resp){
				if(resp === '0')
				{
					document.getElementById('savebtn').disabled = true;	
					document.getElementById('runbtn').disabled = false;
				}
			}
		});
}

</script>
<?php include('banner_index.php');?>
<div id="resulReportDiv" style="display:none;"></div>
<div id="screen1" class="screen1"></div>
<div id="pieDiv"></div>
<form name="frmreport" method="post" id="frmreport">
<div id="resultDiv" class="hidden" height="600px"></div>
<div class="container">
<table width="100%" id="table1" style="border:2px solid gray;" border-spacing="0" cellspacing="0" cellpadding="0">
<tr style="line-height:40px;">
<td colspan="2" style="text-align:center;background-color:#B1CE64;">
	<b>VAPT Settings</b>
</td>
</tr>
<tr>
<td colspan="2">
<div id="err_msg_ip" style="display:none;background:#FAFAAA;margin:10px;padding-left:10px;padding-top:8px;padding-bottom:8px;border-radius:12px;font-size:10px;font-family: 'Verdana','Arial','Helvetica','sans-serif';"></div>
</td>
</tr>
</tr>
<tr>
<td style="text-align:center;width:50%;padding-top: 10px;">
Vulnerabilities:
</td>
<td style="text-align:center;width:50%;background-color:#F4F3F2;padding-top: 10px;">
<select name="vulnera" id="vulnera">
<option value="/auxiliary/scanner/smb/smb_ms17_010">/auxiliary/scanner/smb/smb_ms17_010</option>
</select>
</td>
</tr>
<tr>
<td style="text-align:center;width:50%">
<input type="radio" name="userChoice" value="0" onclick="enaDisableRange('0')" id="IP_rad"><label>IP</label></input>
<input type="radio" name="userChoice" value="1" onclick="enaDisableRange('1')" id="IP_range_rad"><label>IP Range:</label></input>
</td>
<td style="text-align:center;width:50%;background-color:#F4F3F2;">
<table style="white-space:nowrap;margin:auto;">
                <tr style="height:35px;"><td colspan="5"></td></tr>
                <tr><td colspan="5"></td></tr>
                <tr id="startipTR">
                        <td id="chgcontaintxt">Starting IP Address<b style="color:red;">*</b>:</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="StartIP1" name="StartIP1" onkeypress="return isIP(event, this.id);" onchange="SetEndIP(this.id);" onkeyup="CheckSize(event,this.id);" /></td><td>.</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="StartIP2" name="StartIP2" onkeypress="return isIP(event, this.id);" onchange="SetEndIP(this.id);" onkeyup="CheckSize(event,this.id);" /></td><td>.</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="StartIP3" name="StartIP3" onkeypress="return isIP(event, this.id);" onchange="SetEndIP(this.id);" onkeyup="CheckSize(event,this.id);" /></td><td>.</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="StartIP4" name="StartIP4" onkeypress="return isIP(event, this.id);" onkeyup="CheckSize(event,this.id);" /></td>
                </tr>
                </table>
                <table style="white-space:nowrap;margin:auto;">
                <tr id="endipTR">
                        <td style="padding-left:2px;">Ending IP  Address<b style="color:red;">*</b>:&nbsp; </td>
                        <td><INPUT type="text" maxLength="3" size="3" id="EndIP1" name="EndIP1" disabled /></td><td>.</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="EndIP2" name="EndIP2" disabled /></td><td>.</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="EndIP3" name="EndIP3" disabled onkeypress="return isIP(event, this.id);" onkeyup="CheckSize(event,this.id);" /></td><td>.</td>
                        <td><INPUT type="text" maxLength="3" size="3" id="EndIP4" name="EndIP4" onkeypress="return isIP(event, this.id);" onkeyup="CheckSize(event,this.id);" onKeyDown="if (event.keyCode==13) jsSaveIPRange();" /></td>
                </tr>
                <tr></tr>
                <tr style="height:35px;"><td colspan="5"></td></tr>
                </table>
</td>
</tr>
<tr style="background-color:gray;">
<td colspan="2" style="text-align:center;padding-top:5px;;padding-bottom:5px;">
<!--input type="submit" value="Save" name="OK" onclick="enableRun();";></input-->
<input type="button" value="Save" name="OK" onclick="jsSaveIPRange();" id="savebtn" class="actionbutton">
<input type="button" value="Run" onclick="generateReport();" id="runbtn" class="actionbutton" disabled></input>
</td>
</tr>
<tr style="background-color:#B1CE64;">
<td colspan="2" style="text-align:right;display:none;padding-top:5px;padding-bottom:5px;padding-right:5px;" id="txtlbl">Export to:
<button id="pdfBtn" style="display:none;" class="actionbutton">View PDF</button>
<button id="htmlBtn" style="display:none;" class="actionbutton">View HTML</button>
<label id="txtlbl1" style="color:red;">No Data Found to Export!</label>
</td>
</tr>
</table>
</form>
</div>
<script>
	$(document).ready(function(){
	/*	$('#pdfBtn').click(function(){
			$('#resulReportDiv').css('display','block');	
			var pdfObj = new jsPDF('p', 'pt', 'a4');
                	var TableElem = document.getElementById('ExportTable');
                	var res = pdfObj.autoTableHtmlToJson(TableElem);
                	pdfObj.autoTable(res.columns,res.data,{startY:20,margin: {top: 10, left: 10, right: 10, bottom:10},styles:{ overflow: 'linebreak'}});

                	pdfObj.save('report.pdf');
			$('#resulReportDiv').css('display','none');
			return false;
		});
	*/
		/*function createPieChart(id,chartType,Title,data) //function to create Pie Chart
                {
                        $(id).highcharts({
                                        chart:{
                                        type:chartType,
                                        backgroundColor:'',
                                        plotBackgroundColor:'',
                              },
                        credits:false, // to remove highchart.com link
                        title:{
                                text:Title
                              },
                        plotOptions: {
                                        pie: {
                                                allowPointSelect: false,
                                                cursor: 'pointer',
                                                borderWidth:0,
                                                borderColor:null,
                                                size:200,
                                                dataLabels:{
                                                                enabled: true,
                                                                format: '{point.name}-{point.y:.1f}'
                                                           },
                                                showInLegend: true,
                                                series: {
                                                                states: {
                                                                            hover: {
                                                                                     enabled: false
                                                                                    }
                                                                        }
                                                        }

                                            }
                                      },
                        series:data
                });
        }//createPieChart end here
	*/
	var id = $('#pieDiv');
        var Title = "eScan VAPT Report Summary";
        var chartType = "pie";
        var pdata = [{name:' ',colorByPoint:true,data:[{name:'Not Vulnerable',color:'#42Ab6E',y:pVul},{name:'Vulnerable',color:'#F37A6C',y:nVul},{name:'Unknown',color:'#999999',y:unVul}]}];
//cireatePieChart(id,chartType,Title,pdata);

//UrlData

$(function(H) {
	//alert(H);
	//console.log(H);
            H.Chart.prototype.createCanvas = function(divId) {
                var svg = this.getSVG(),
                    width = parseInt(svg.match(/width="([0-9]+)"/)[1]),
                    height = parseInt(svg.match(/height="([0-9]+)"/)[1]),
                    canvas = document.createElement('canvas');

                canvas.setAttribute('width', width);
                canvas.setAttribute('height', height);

                if (canvas.getContext && canvas.getContext('2d')) {

                    canvg(canvas, svg);

                    return canvas.toDataURL("image/jpeg");
                        

                }
                else {
                    alert("Your browser doesn't support this feature, please use a modern browser");
                    return false;
                }

            }
        }(Highcharts));

		$('#pdfBtn').click(function(){
			$('#resulReportDiv').css('display','block');
                        var dateTime = Date();
			var dateTimeF = dateTime.slice(0,dateTime.lastIndexOf('('));
			$('#pieDiv').each(function(index) {
                                 imageData = $(this).highcharts().createCanvas();
                                //console.log(imageData);
                        });
                        var pdfObj = new jsPDF('p', 'pt', 'a4');
                        var totalPagesExp = "{total_pages_count_string}";
                	
                        //pdfObj.addImage(leftimg,'JPEG',11,10,300,40);
                        //pdfObj.addImage(rightImg,'JPEG',300,10,285,40);
                        //console.log(leftimg);
                        pdfObj.addImage(leftimg, 'JPEG', 0, 0, 50, 50); //Coverpage header left image
                        pdfObj.addImage(verticalImg,'JPEG',390,60,5,700);
                        pdfObj.addImage(horizontalImg,'JPEG',25,350,367,5);
                        pdfObj.addImage(middleImg,'JPEG',46,0,285,50);  // CoverPage header middle image
                        pdfObj.addImage(rightImg,'JPEG',300,0,300,50); //  CoverPage header right image
                        //CoverPage Footer
                        pdfObj.addImage(leftimg, 'JPEG', 0, 803,50, 40);
                        pdfObj.addImage(middleImg,'JPEG',46,803,550,40);
                        pdfObj.setFontSize(40);
                        pdfObj.text("eScan Reports",60,340);
                        pdfObj.setFontSize(12);
                        pdfObj.text("eScan VAPT Report PDF",60,370);
                        pdfObj.text("eScan VAPT",130,30);
                        pdfObj.setFontSize(9);
                        pdfObj.text("Generated On :",400,400);
                        pdfObj.text(""+dateTimeF,400,410);      
			pdfObj.text("eScan VAPT", 520, pdfObj.internal.pageSize.height - 15);
			pdfObj.addPage();
			pdfObj.addImage(imageData,'JPEG',100,80,420,300); 

                        var TableElem = document.getElementById('ExportTable');
                        var res = pdfObj.autoTableHtmlToJson(TableElem);
                                
                        var header = function(data) {
                                       /* pdfObj.setFontSize(12);
                                        pdfObj.setTextColor(40);
                                        pdfObj.setFontStyle('normal');
                                        pdfObj.addImage(leftimg, 'JPEG', data.settings.margin.left, 20, 50, 50);
                                        pdfObj.addImage(middleImg,'JPEG',66,20,285,50);
                                        pdfObj.text('eScan VAPT Report',100,40);
                                        pdfObj.setFontSize(9);
                                        pdfObj.text(dateTimeF,80,55);
                                        pdfObj.addImage(rightImg,'JPEG',260,20,315,50);
					*/
					pdfObj.setFontSize(12);
                                        pdfObj.setTextColor(40);
                                        pdfObj.setFontStyle('normal');
                                        pdfObj.addImage(leftimg, 'JPEG', 0, 0, 50, 50);
                                        pdfObj.addImage(middleImg,'JPEG',46,0,285,50);
                                        pdfObj.text('eScan VAPT Report',100,20);
                                        pdfObj.setFontSize(9);
                                        pdfObj.text(dateTimeF,80,35);
                                        pdfObj.addImage(rightImg,'JPEG',300,0,300,50);

                                        //pdfObj.text(" Report Header", data.settings.margin.left, 50);
                                        //console.log(data.settings.margin.left); 
                                };
			var footer = function (data) {
                                /*      var str = 'Page ' + data.pageCount;
                                        // Total page number plugin only available in jspdf v1.0+
                                        if (typeof pdfObj.putTotalPages === 'function') {
                                                str = str + ' of ' + totalPagesExp;
                                }*/
                                pdfObj.addImage(leftimg, 'JPEG', 0,pdfObj.internal.pageSize.height - 38, 50, 40);
                                pdfObj.addImage(middleImg,'JPEG',46,pdfObj.internal.pageSize.height - 38,550,40);
                                pdfObj.text("eScan VAPT", 520, pdfObj.internal.pageSize.height - 15);
                        };
                        //console.log(data.settings.margin.left);                       

                        //pdfObj.autoTable(res.columns,res.data,{startY:50,margin: {top: 10, left: 10, right: 10, bottom:10},styles:{ overflow: 'linebreak'}});
                        //pdfObj.addPage();
                        //pdfObj.autoTable(res.columns,res.data,{beforePageContent: header,startY:70,margin: {top:70,left: 20,right:20}});
			pdfObj.autoTable(res.columns,res.data,{beforePageContent: header,afterPageContent:footer,startY:420,styles: {rowHeight:17},margin: {top:70,left: 20,right:20}});
			//pdfObj.addImage(imageData,'JPEG',100,200,400,300);
			pdfObj.save("eScanVAPT.pdf");
			$('#resulReportDiv').css('display','none');
                        return false;
                        
                });	
	});
	$('#htmlBtn').click(function(){
		var r = pVul +'|' + nVul + '|' + unVul;
		//window.open("read_report_html.php?p="+r);
		window.open("read_report_html.php?p="+r,"","location=no");
		return false;
	});
</script>
</body>
</html>
